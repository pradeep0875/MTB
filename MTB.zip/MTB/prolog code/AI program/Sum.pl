sum(X,Y,Z):- Z is X+Y.
