import numpy as np

def encrypt(secret, depth, key):
    msg = np.array(list(secret))

    encrypted = ""
    
    if len(msg) % depth != 0:
        msg = np.append(msg, ['X'] * (depth - len(msg) % depth))
    
    msg = msg.reshape((depth, -1))[:, np.argsort(key)].T

    for group in msg:
        encrypted += "".join(group)
    
    return encrypted

def decrypt(secret, depth, key):
    msg = np.array(list(secret))

    decrypted = ""
    
    msg = msg.reshape((-1, depth)).T

    msg = msg[:, key]

    for group in msg:
        decrypted += "".join(group)
    
    return decrypted

secret = str(input("Enter the secret: ")).replace(" ", "").upper()

depth = int(input("Enter the depth: "))

key = list(map(int, input("Enter the key: ").strip().split()))

if key == []:
    key = np.arange(len(secret) // depth + 1)

encrypted = encrypt(secret, depth, key)
double_encrypted = encrypt(encrypted, depth, key)

decrypted = decrypt(encrypted, depth, key)
double_decrypted = decrypt(decrypt(double_encrypted, depth, key), depth, key)

print("Encrypted: ", encrypted)
print("Double Encrypted: ", double_encrypted)

print("Decrypted: ", decrypted)
print("Double Decrypted: ", double_decrypted)